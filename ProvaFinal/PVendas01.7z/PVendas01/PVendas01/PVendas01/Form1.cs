using Microsoft.VisualBasic;
using System.Security.Cryptography;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[3, 4];
            double totalM = 0, totalGlobal = 0;

            for (int mes = 0; mes < 3; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    string input = Interaction.InputBox($"Digite o valor da semana {semana + 1} para o m�s {mes + 1}:", "Entrada de Dados");
                    if (double.TryParse(input, out double valor) && valor >= 0)
                    {
                        matriz[mes, semana] = valor;
                    }
                    else
                    {
                        MessageBox.Show("Valor inv�lido");

                    }
                }
            }

            for (int mes = 0; mes < 3; mes++)
            {
                totalM = 0;
                for (int semana = 0; semana < 4; semana++)
                {
                    listBox1.Items.Add($"Total do m�s: {mes + 1} Semana: {semana + 1} {matriz[mes, semana]:F2}");
                    totalM += matriz[mes, semana];
                }
                totalGlobal += totalM;
                listBox1.Items.Add($"Total do m�s: {totalM:F2}");
                listBox1.Items.Add("------------------------------");
            }
            listBox1.Items.Add($"Total Geral: {totalGlobal:F2}");
        }
    }
}
