﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace PLoops
{
    public partial class FrmEx3 : Form
    {
        public FrmEx3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada = textBox1.Text;

            if (entrada.Length > 50)
            {
                MessageBox.Show("O texto não pode ter mais do que 50 caracteres.");
                return;
            }

            // Remover espaços, acentos e converter para maiúsculas
            string textoLimpo = RemoverAcentos(entrada).ToUpper().Replace(" ", "");

            // Verificar se é palíndromo
            string invertido = new string(textoLimpo.Reverse().ToArray());

            if (textoLimpo == invertido)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }

        private string RemoverAcentos(string texto)
        {
            return new string(
                texto.Normalize(NormalizationForm.FormD)
                     .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                     .ToArray());
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Não é necessário implementar nada aqui para essa tarefa
        }
    }
}
