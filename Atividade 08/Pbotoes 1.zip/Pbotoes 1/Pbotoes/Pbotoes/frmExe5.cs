﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pbotoes
{
    public partial class frmExe5 : Form
    {
        public frmExe5()
        {
            InitializeComponent();
        }

        private void btnCorrigir_Click(object sender, EventArgs e)
        {

            int digitoFinalRA = 7;
            int numeroAlunos = digitoFinalRA == 0 ? 2 : digitoFinalRA + 1;
            int numeroQuestoes = 10;


            char[] vetorGabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] matrizRespostas = new char[numeroAlunos, numeroQuestoes];

            lstResultado.Items.Clear();


            for (int aluno = 0; aluno < numeroAlunos; aluno++)
            {
                for (int questao = 0; questao < numeroQuestoes; questao++)
                {
                    string entrada;
                    bool respostaValida;
                    do
                    {
                        entrada = Interaction.InputBox($"Aluno {aluno + 1} - Questão {questao + 1} (A-E):", "Respostas");

                       
                        if (entrada == "")
                        {
                            MessageBox.Show("Operação cancelada pelo usuário.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        respostaValida = entrada.Length == 1 && "ABCDE".Contains(entrada.ToUpper());

                        if (!respostaValida)
                        {
                            MessageBox.Show("Resposta inválida. Digite apenas A, B, C, D ou E.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }

                    } while (!respostaValida);


                    matrizRespostas[aluno, questao] = char.ToUpper(entrada[0]);
                }
            }


            for (int aluno = 0; aluno < numeroAlunos; aluno++)
            {
                int acertos = 0;
                for (int questao = 0; questao < numeroQuestoes; questao++)
                {
                    if (matrizRespostas[aluno, questao] == vetorGabarito[questao])
                    {
                        acertos++;
                    }
                }
                lstResultado.Items.Add($"Aluno {aluno + 1}: {acertos} acerto(s)");
            }
        }
    }

}