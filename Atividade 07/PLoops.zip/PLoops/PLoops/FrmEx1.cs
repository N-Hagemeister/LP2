﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FrmEx1 : Form
    {
        public FrmEx1()
        {
            InitializeComponent();
        }

        private void FrmEx1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int espaco = 0;
            string texto = CaixaTexto.Text;

            for (int i = 0; i < texto.Length; i++)
            {
                if (texto[i] == ' ')
                {
                    espaco++;
                }
            }
            MessageBox.Show($"Quantidade de espaços em branco: {espaco}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int contadorR = 0;
            string texto = CaixaTexto.Text;
            int i = 0;

            while (i < texto.Length)
            {
                if (texto[i] == 'r' || texto[i] == 'R')
                {
                    contadorR++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de R's: {contadorR}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contador = 0;
            string texto = CaixaTexto.Text;
            int i = 0;

            while (i < texto.Length - 1)
            {
                if (texto[i] == texto[i+1])
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras repetidas: {contador}");
        }
    }
}
