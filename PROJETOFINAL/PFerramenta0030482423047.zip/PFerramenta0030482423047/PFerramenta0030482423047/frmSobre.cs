﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482423047
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Somos uma Empresa Júnior " +
                "formada por alunas do curso de Análise e " +
                "Desenvolvimento de Sistemas da Fatec Sorocaba, Isabelli, Raiane e Nicole " +
                "nos juntamos para focar no desenvolvimento de soluções tecnológicas inovadoras. " +
                "Nosso principal projeto é uma plataforma de cadastro de ferramentas de programação, " +
                "que tem como objetivo facilitar o acesso e a organização de recursos para desenvolvedores, " +
                "estudantes e profissionais de tecnologia. A plataforma permite que os usuários encontrem, " +
                "classifiquem e compartilhem informações sobre linguagens, " +
                "frameworks, bibliotecas, IDEs e demais ferramentas do universo " +
                "da programação, promovendo a colaboração, o aprendizado e a evolução da comunidade tech.");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
